﻿namespace $safeprojectname$.Abstractions
{
    public interface IPrimeNumberDeterminator
    {
        bool IsPrime(int number);
    }
}