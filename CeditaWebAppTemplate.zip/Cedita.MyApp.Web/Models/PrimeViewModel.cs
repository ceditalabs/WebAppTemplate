﻿namespace $safeprojectname$.Models
{
    public class PrimeViewModel
    {
        public int Number { get; set; }

        public bool IsPrime { get; set; }
    }
}
